package TomcatDemo;

import java.io.PrintWriter;

public class Response {
	private PrintWriter writer;	
	
	public Response(PrintWriter writer) {
		super();
		this.writer = writer;
	}

	public void write(String msg) {
		writer.write(msg);
		writer.flush();//ˢ��
	}
}

package TomcatDemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.xml.sax.InputSource;

import servlet.HttpServlet;

public class Handler implements Runnable{
	private Socket socket;
	private PrintWriter writer;

	public Handler(Socket socket) {
		super();
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			writer=new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
			writer.println("HTTP/1.1 200 OK");
			writer.println("Content-Type:text/html;charset=UTF-8");
			writer.println();
			
			//��װrequest response
			Request request=new Request();
			Response response=new Response(writer);
			
			//��ȡ������Ϣ
			InputStream inputStream=socket.getInputStream();
			BufferedReader reader=new BufferedReader(new InputStreamReader(inputStream));
			
			while(true) {
				String msg=reader.readLine();
				if(null==msg || "".equals(msg.trim())) {
					break;
				}
				String[] msgs=msg.split(" ");// [GET, /, HTTP/1.1]��[GET, /favicon.ico, HTTP/1.1]
				System.out.println(Arrays.toString(msgs));
				if(3==msgs.length && "HTTP/1.1".equalsIgnoreCase(msgs[2])) {
					request.setMethod(msgs[0]);
					request.setPath(msgs[1]);
					//   /index?name=zhangsan&pwd=123456
					String[] attributesPath=msgs[1].split("\\?");
					request.setPath(attributesPath[0]);// /index
					if(attributesPath.length>1) {
						Map<String,String> attributeMap=new HashMap<>();
						String[] params=attributesPath[1].split("&");// name=zhangsan&pwd=123456
						for(int i=0;i<params.length;i++) {
							attributeMap.put(params[i].split("=")[0], params[i].split("=")[1]);// name,zhangsan
						}
						request.setAttribute(attributeMap);
					}
					
					
					break;
				}
				//System.out.println(msgs[0]+" "+msgs[1]+" "+msgs[2]);
			}
			
			if(request.getPath().endsWith("ico")) {
				return;
			}
			//����servlet
			HttpServlet httpServlet=request.initServlet();
			//����ַ�
			dispatcher(httpServlet,request,response);
			
			
			//writer.print("<h1>hello world</h1>");	
		} catch (Exception e) {			
			e.printStackTrace();
		} finally {			
			try {
				writer.close();
				socket.close();
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}

	}

	private void dispatcher(HttpServlet httpServlet, Request request, Response response) {
		try {
			if(null==httpServlet) {
				response.write("<h1>404 not found</h1>");
				return;
			}
			if("GET".equalsIgnoreCase(request.getMethod())) {
				httpServlet.doGet(request, response);
			}else if("POST".equalsIgnoreCase(request.getMethod())) {
				httpServlet.doGet(request, response);
			}
		}catch(Exception e) {
			response.write("<h1>500 internal server error </h1>\r\n"+Arrays.toString(e.getStackTrace()));
			e.printStackTrace();
		}
		
	}
	
}

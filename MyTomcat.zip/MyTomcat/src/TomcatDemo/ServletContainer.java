package TomcatDemo;

import java.util.HashMap;
import java.util.Map;

import javax.swing.text.StyledEditorKit.ForegroundAction;

import model.Servlet;
import model.ServletMapping;
import servlet.HttpServlet;
import util.XMLUtil;

public class ServletContainer {
	private static Map<String,Object>servletMaps=new HashMap<>();
	private static Map<String,Object>servletMappingMaps=new HashMap<>();
	private static Map<String,HttpServlet>servletContainer=new HashMap<>();
	//ͨ����̬����������ļ���ӳ���Ӧ��modelʵ��
	static {
		try {
			Map<Integer,Map<String,Object>> maps=XMLUtil.parseWebXML();
			if(null!=maps && 2==maps.size()) {
				servletMaps=maps.get(0);
				servletMappingMaps=maps.get(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	//��servlet�����л�ȡ��Ӧ��servlet
	public static HttpServlet getHttpServlet(String path) {
		//���ʸ�·�� "/"   �޸�Ϊ  "/index"
		if(null==path || "".equals(path.trim()) || "/".equals(path)) {
			path="/index";
		}
		if(servletContainer.containsKey(path)) {
			return servletContainer.get(path);
		}
		if(!servletMappingMaps.containsKey(path)) {
			return null;
		}
		ServletMapping servletMapping=(ServletMapping) servletMappingMaps.get(path);
		String name=servletMapping.getName();
		if(!servletMaps.containsKey(name)) {
			return null;
		}
		Servlet servlet=(Servlet) servletMaps.get(name);
		String clazz=servlet.getClazz();
		if(null==clazz || "".equals(clazz.trim())) {
			return null;
		}
		
		HttpServlet httpServlet=null;
		try {
			httpServlet=(HttpServlet) Class.forName(clazz).newInstance();//ͨ�������ȡservletʵ��
			servletContainer.put(path, httpServlet);//���ӵ�servlet������
		} catch (Exception e) {			
			e.printStackTrace();
		}		
				
		return httpServlet;
	}
	
}

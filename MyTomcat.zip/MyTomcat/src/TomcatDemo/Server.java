package TomcatDemo;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
	private static ServerSocket serverSocket;
	private static int port=8088;
	private ExecutorService executorService;
	private final int POOL_SIZE=15;
	
	
	public void start() {
		try {
			serverSocket=new ServerSocket(port);			
			System.out.println("starting....... "+port);	
			Socket socket=null;
			executorService=Executors.newFixedThreadPool(POOL_SIZE);
			
			while(true) {
				socket=serverSocket.accept();
				executorService.execute(new Handler(socket));
			}			
			
		} catch (IOException e) {			
			e.printStackTrace();
		}
	
	}
	
	public static void main(String[] args) {
		new Server().start();//���� localhost:8080/index?name=zhangsan&pwd=123456
	}
}

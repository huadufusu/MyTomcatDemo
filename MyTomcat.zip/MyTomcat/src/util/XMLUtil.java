package util;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import model.Servlet;
import model.ServletMapping;

public class XMLUtil {
	public static Map<Integer,Map<String,Object>> parseWebXML() throws Exception{
		Map<Integer,Map<String,Object>> result=new HashMap<Integer,Map<String,Object>>();
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		DocumentBuilder db=dbf.newDocumentBuilder();		
		
		InputStream in=XMLUtil.class.getClassLoader().getResourceAsStream("web.xml");
		Document document=db.parse(in);
		Element root=document.getDocumentElement();
		System.out.println("rootName: "+root.getTagName());//web-app
		
		NodeList xmlNodes=root.getChildNodes();		
		for(int i=0;i<xmlNodes.getLength();i++) {
			Node config=xmlNodes.item(i);			
			if(null!=config && config.getNodeType()== Node.ELEMENT_NODE) {
				String nodeName1=config.getNodeName();
				System.out.println("nodeName1: "+nodeName1);//servlet servlet-mapping				
				if("servlet".equals(nodeName1)) {
					Map<String,Object> servletMaps=null;
					if(result.containsKey(0)) {
						servletMaps=result.get(0);
					}else {
						servletMaps=new HashMap<String,Object>();
					}					
					NodeList childNodes=config.getChildNodes();
					Servlet servlet=new Servlet();					
					for(int j=0;j<childNodes.getLength();j++) {						
						Node node =childNodes.item(j);						
						if(null!=node && node.getNodeType()== Node.ELEMENT_NODE) {//	???????????					
							String nodeName2=node.getNodeName();
							System.out.println("nodeName2: "+nodeName2);//servlet-name servlet-class
							String textContext=node.getTextContent();
							System.out.println("textContext: "+textContext);
							if("servlet-name".equals(nodeName2)) {
								servlet.setName(textContext);
							}else if("servlet-class".equals(nodeName2)) {
								servlet.setClazz(textContext);
							}
						}
					}
					servletMaps.put(servlet.getName(), servlet);
					result.put(0, servletMaps);					
					
				}else if("servlet-mapping".equals(nodeName1)) {
					Map<String,Object> servletMappingMaps=null;
					if(result.containsKey(1)) {
						servletMappingMaps=result.get(1);
					}else {
						servletMappingMaps=new HashMap<String,Object>();
					}
					
					NodeList childNodes=config.getChildNodes();
					ServletMapping servletMapping=new ServletMapping();
					
					for(int j=0;j<childNodes.getLength();j++) {
						Node node =childNodes.item(j);
						if(null!=node && node.getNodeType()==Node.ELEMENT_NODE) {
							String nodeName2=node.getNodeName();
							System.out.println("nodeName2: "+nodeName2);//servlet-name url-pattern
							String textContext=node.getTextContent();
							System.out.println("textContext: "+textContext);
							if("servlet-name".equals(nodeName2)) {
								servletMapping.setName(textContext);
							}else if("url-pattern".equals(nodeName2)) {
								servletMapping.setUrl(textContext);
							}
						}
					}
					servletMappingMaps.put(servletMapping.getUrl(), servletMapping);
					result.put(1, servletMappingMaps);
				}
			}
		}
		return result;
	}
	
	public static void main(String[] args) throws Exception {
		System.out.println(parseWebXML());
	}
}

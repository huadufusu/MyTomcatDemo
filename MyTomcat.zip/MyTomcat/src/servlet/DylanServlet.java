package servlet;

import TomcatDemo.Request;
import TomcatDemo.Response;

public class DylanServlet extends HttpServlet{

	@Override
	public void doGet(Request request, Response response) {
		
		response.write("<h1>servlet get response!</h1><br>"+
				"name: "+request.getParameter("name")+" , pwd: "+request.getParameter("pwd"));
	}
	
}



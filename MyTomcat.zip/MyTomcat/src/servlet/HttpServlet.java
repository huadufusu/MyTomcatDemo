package servlet;

import TomcatDemo.Request;
import TomcatDemo.Response;

public abstract class HttpServlet {
	public void doGet(Request request,Response response) {
		this.service(request, response);
	}
	public void doPost(Request request,Response response) {
		this.service(request, response);
	}
	public void service(Request request,Response response) {
		if("GET".equalsIgnoreCase(request.getMethod())) {
			doGet(request, response);
		}else {
			doPost(request, response);
		}
	}
}
